package com.iraqistudio.ai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF10131A)
private val Panel = Color(0xFF1B202B)
private val Mint = Color(0xFF70D6B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedTab by remember { mutableStateOf("الفيديو") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { videoUri = it }
    val player = remember(videoUri) {
        videoUri?.let { uri -> ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() } }
    }
    DisposableEffect(player) { onDispose { player?.release() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Ink, surface = Panel)) {
        Scaffold(containerColor = Ink, topBar = {
            TopAppBar(
                title = { Column {
                    Text("Iraqi Studio AI", fontWeight = FontWeight.Bold, color = Color.White)
                    Text("استوديو المونتاج الذكي", fontSize = 11.sp, color = Mint)
                } },
                actions = { Text("0.1", color = Color.LightGray, modifier = Modifier.padding(end = 16.dp)) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("مشروع جديد", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Button(onClick = { picker.launch("video/*") }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink)) {
                        Icon(Icons.Default.Add, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("اختيار فيديو")
                    }
                }
                Box(Modifier.fillMaxWidth().height(220.dp).background(Color(0xFF080A0F), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    if (player != null) {
                        AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
                    } else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Movie, contentDescription = null, tint = Mint, modifier = Modifier.size(42.dp))
                        Spacer(Modifier.height(8.dp)); Text("اختر فيديو للبدء", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("ستظهر المعاينة هنا", color = Color.Gray, fontSize = 12.sp)
                    }
                }
                Text("أدوات التحرير", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                val sections = listOf(
                    "تحرير الجسم والعضلات" to "توسيع الكتفين • إبراز العضلات • تعديل الخصر",
                    "تحرير ملامح الوجه" to "العيون • الأنف • الفم • الفك والخدود",
                    "البشرة والعيون" to "تنعيم • توهج زجاجي • إزالة الهالات",
                    "حماية اللحية والشارب" to "حفظ اللون والوضوح والتفاصيل الأصلية",
                    "الألوان الانتقائية" to "الوجه • الملابس • الخلفية • السماء",
                    "عزل الخلفية والبورتريه" to "ضبابية • إزالة الخلفية • استبدالها",
                    "تحسين الفيديو" to "تقليل التشويش • الحدة • تثبيت الاهتزاز",
                    "الصوت والتصدير" to "MP4 • H.264 • 1080p / 2K مستهدف"
                )
                sections.forEach { (title, subtitle) ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp)); Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp)); Text("ضمن خطة التطوير — غير مفعّل في هذه النسخة الأولية", color = Mint, fontSize = 10.sp)
                        }
                    }
                }
                Text("ملاحظة: هذه نسخة تأسيسية لاختبار اختيار الفيديو ومعاينته. أدوات الذكاء الاصطناعي والتصدير ستُنفّذ وتُختبر على مراحل.", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
